<?php

if (isset($_POST['signup'])) {

    require 'config.php';
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];


    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        header("Location: ../register.html?error=emptyfields" "&username=" .$username."&email=" .$email); //if username and email were filled out, both get sent back to signup page
        exit();
    }
    //check if email and username is valid
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $username)) {
        header("Location: ../register.html?error=invalidemail" "username=" .$username);
        exit();
    }

    //checks if email is valid
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../register.html?error=invalidemail" "&username=" .$username);
        exit();

    }
    //checks if username is valid
    elseif (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
        header("Location: ../register.html?error=invalidusername" "&email=" .$email);
        exit();
    }
    //checks if password match
    elseif ($password !== $confirm_password) {
        header("Location: ../register.html?error=passwordcheck" "&username=".$username."&email=".$email);
        exit();
    }
    //checks database if there is matching users in database
    else {
        $sql = "SELECT username FROM username_table WHERE username=?";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli.stmt_prepare($stmt, $sql)) {
            header("Location: ../register.html?error=sqlerror");
            exit();
        }
        else {
            mysqli_stmt_bind_param($stmt, "s", $username); //string type data that is being passed which is username
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $resultCheck = mysqli_stmt_num_rows($stmt); //checks how many results inside stmt

            //if resultCheck > 0 then username is taken
            if($resultCheck > 0) {
                header("Location: ../register.html?error=usernametaken" "&email=" .$email);
                exit();
            }
            else {
                $sql = "INSERT INTO user_table(username, email, password) VALUES(?, ?, ?)";
                $stmt = mysqli_stmt_init($conn);
                
                if (!mysqli_stmt_prepare($stmt, $sql)) {
                    header("Location: ../register.html?error=sqlerror")
                    exit();
                }
                else {
                    $hashedpassword = password_hash($password, PASSWORD_DEFAULT); //for security purpose

                    mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashedpassword);
                    mysqli_stmt_execute($stmt);
                    header("Location: ../register.html?signup=success")
                    exit();
                }
                
            }

        }
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conn);

}
else {
    header("Location: ../register.html");
    exit();
}